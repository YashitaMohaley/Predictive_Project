


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.dummy import DummyClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, ConfusionMatrixDisplay
)
from sklearn.inspection import permutation_importance



DATA_PATH = r"C:\Users\LENOVO\Downloads\online+shoppers+purchasing+intention+dataset\online_shoppers_intention.csv"
df = pd.read_csv(DATA_PATH)

print("Dataset shape before cleaning:", df.shape)
print("\nMissing values by column:\n", df.isnull().sum())
print("\nTotal missing values:", df.isnull().sum().sum())
print("\nTarget distribution:\n", df["Revenue"].value_counts(dropna=False))

duplicate_count = df.duplicated().sum()
print("\nDuplicate rows:", duplicate_count)
df = df.drop_duplicates().copy()
print("Dataset shape after removing duplicates:", df.shape)

for col in df.columns:
    if df[col].isnull().any():
        if pd.api.types.is_numeric_dtype(df[col]):
            df[col] = df[col].fillna(df[col].median())
        else:
            mode_values = df[col].mode(dropna=True)
            if not mode_values.empty:
                df[col] = df[col].fillna(mode_values.iloc[0])

df["Revenue"] = df["Revenue"].astype(int)
df["Weekend"] = df["Weekend"].astype(int)

plt.figure(figsize=(6, 4))
sns.countplot(x="Revenue", data=df)
plt.title("Purchase vs No Purchase")
plt.xlabel("Revenue (0 = No Purchase, 1 = Purchase)")
plt.tight_layout()
plt.show()

plt.figure(figsize=(8, 4))
sns.countplot(x="VisitorType", hue="Revenue", data=df)
plt.title("Visitor Type vs Purchase")
plt.tight_layout()
plt.show()

plt.figure(figsize=(10, 4))
sns.countplot(x="Month", hue="Revenue", data=df,
              order=["Jan", "Feb", "Mar", "Apr", "May", "June",
                     "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"])
plt.title("Month vs Purchase")
plt.xticks(rotation=30)
plt.tight_layout()
plt.show()

numeric_before_encoding = df.select_dtypes(include="number")
plt.figure(figsize=(12, 8))
sns.heatmap(numeric_before_encoding.corr(), cmap="coolwarm", center=0)
plt.title("Correlation Heatmap (Numeric Features)")
plt.tight_layout()
plt.show()

outlier_cols = [
    col for col in df.select_dtypes(include="number").columns
    if col != "Revenue"
]
for col in outlier_cols:
    plt.figure(figsize=(7, 3))
    sns.boxplot(x=df[col])
    plt.title(f"Outlier Check: {col}")
    plt.tight_layout()
    plt.show()

duration_cols = [
    "Administrative_Duration",
    "Informational_Duration",
    "ProductRelated_Duration",
]
if all(col in df.columns for col in duration_cols):
    df["TotalPageDuration"] = df[duration_cols].sum(axis=1)

df = pd.get_dummies(
    df,
    columns=["Month", "VisitorType"],
    drop_first=True,
    dtype=int
)

X = df.drop("Revenue", axis=1)
y = df["Revenue"]

splits = {"70-30": 0.30, "75-25": 0.25, "80-20": 0.20}
results = []
split_data = {}

def get_models():
    return {
        "Logistic Regression": Pipeline([
            ("scaler", StandardScaler()),
            ("model", LogisticRegression(max_iter=2000, random_state=42))
        ]),
        "Decision Tree": DecisionTreeClassifier(random_state=42),
        "Random Forest": RandomForestClassifier(random_state=42, n_jobs=-1),
        "KNN": Pipeline([
            ("scaler", StandardScaler()),
            ("model", KNeighborsClassifier())
        ]),
        "Naive Bayes": Pipeline([
            ("scaler", StandardScaler()),
            ("model", GaussianNB())
        ]),
    }

for split_name, test_size in splits.items():
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=test_size,
        random_state=42,
        stratify=y
    )
    split_data[split_name] = (X_train, X_test, y_train, y_test)

    baseline = DummyClassifier(strategy="most_frequent")
    baseline.fit(X_train, y_train)
    baseline_pred = baseline.predict(X_test)
    results.append({
        "Split": split_name,
        "Algorithm": "Dummy Baseline",
        "Accuracy": round(accuracy_score(y_test, baseline_pred), 4),
        "Precision": round(precision_score(y_test, baseline_pred, zero_division=0), 4),
        "Recall": round(recall_score(y_test, baseline_pred, zero_division=0), 4),
        "F1": round(f1_score(y_test, baseline_pred, zero_division=0), 4),
    })

    for name, model in get_models().items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        results.append({
            "Split": split_name,
            "Algorithm": name,
            "Accuracy": round(accuracy_score(y_test, pred), 4),
            "Precision": round(precision_score(y_test, pred, zero_division=0), 4),
            "Recall": round(recall_score(y_test, pred, zero_division=0), 4),
            "F1": round(f1_score(y_test, pred, zero_division=0), 4),
        })

results_df = pd.DataFrame(results)
print("\nModel comparison results:\n")
print(results_df.to_string(index=False))
results_df.to_csv("results.csv", index=False)
print("\nSaved comparison table to results.csv")

plt.figure(figsize=(12, 5))
sns.barplot(x="Algorithm", y="Accuracy", hue="Split", data=results_df)
plt.xticks(rotation=25, ha="right")
plt.ylim(0, 1)
plt.title("Accuracy by Algorithm and Train-Test Split")
plt.tight_layout()
plt.show()

plt.figure(figsize=(12, 5))
sns.barplot(x="Algorithm", y="F1", hue="Split", data=results_df)
plt.xticks(rotation=25, ha="right")
plt.ylim(0, 1)
plt.title("F1-Score by Algorithm and Train-Test Split")
plt.tight_layout()
plt.show()

print("\nAccuracy table:")
print(results_df.pivot(index="Algorithm", columns="Split", values="Accuracy"))
print("\nF1-score table:")
print(results_df.pivot(index="Algorithm", columns="Split", values="F1"))

X_train, X_test, y_train, y_test = split_data["80-20"]

rf_pipeline = Pipeline([
    ("model", RandomForestClassifier(random_state=42, n_jobs=-1))
])
param_grid = {
    "model__n_estimators": [100, 200],
    "model__max_depth": [None, 10, 20],
    "model__min_samples_split": [2, 5],
    "model__min_samples_leaf": [1, 2],
}
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
grid = GridSearchCV(
    estimator=rf_pipeline,
    param_grid=param_grid,
    scoring="f1",
    cv=cv,
    n_jobs=-1,
    verbose=1
)
grid.fit(X_train, y_train)

best_model = grid.best_estimator_
tuned_pred = best_model.predict(X_test)

print("\nBest Random Forest parameters:", grid.best_params_)
print("Best cross-validation F1-score:", round(grid.best_score_, 4))
print("\nTuned Random Forest test metrics:")
print("Accuracy:", round(accuracy_score(y_test, tuned_pred), 4))
print("Precision:", round(precision_score(y_test, tuned_pred, zero_division=0), 4))
print("Recall:", round(recall_score(y_test, tuned_pred, zero_division=0), 4))
print("F1-score:", round(f1_score(y_test, tuned_pred, zero_division=0), 4))
print("\nClassification report:\n",
      classification_report(y_test, tuned_pred, zero_division=0))

cm = confusion_matrix(y_test, tuned_pred, labels=[0, 1])
disp = ConfusionMatrixDisplay(
    confusion_matrix=cm,
    display_labels=["No Purchase", "Purchase"]
)
disp.plot(cmap="Blues", values_format="d")
plt.title("Tuned Random Forest - Confusion Matrix (80-20 Split)")
plt.tight_layout()
plt.show()

perm = permutation_importance(
    best_model,
    X_test,
    y_test,
    scoring="f1",
    n_repeats=5,
    random_state=42,
    n_jobs=-1
)
importance = pd.Series(
    perm.importances_mean,
    index=X_test.columns
).sort_values(ascending=False)

print("\nTop 15 features by permutation importance (F1 scoring):")
print(importance.head(15))

plt.figure(figsize=(9, 6))
top_importance = importance.head(15).sort_values()
sns.barplot(x=top_importance.values, y=top_importance.index)
plt.title("Top 15 Features - Permutation Importance")
plt.xlabel("Mean decrease in F1 when feature is shuffled")
plt.tight_layout()
plt.show()

importance.rename("PermutationImportance").to_csv("feature_importance.csv")
print("\nSaved feature importance to feature_importance.csv")

print(
    "\nModel selection note: compare the tuned model's test metrics with the "
    "baseline and the other algorithms. Choose based on the business goal "
    "(for example, recall if missing likely purchasers is especially costly, "
    "or F1 if balancing precision and recall is important)."
)